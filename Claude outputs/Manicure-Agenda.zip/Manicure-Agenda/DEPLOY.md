# Colocar a agenda no ar (Hostinger) — mesmo esquema do portal InfotecSoft

A publicação é feita **direto do PC** pelo `publicar-hostinger.bat`, igual ao portal (zenim.me).
Ele empacota o projeto, envia por SSH, grava o `.env` do servidor, aplica as migrations e testa o site.

## 1. Criar o site e o banco na Hostinger (uma vez)

1. **hPanel → Sites → Adicionar site** (ou use um subdomínio, ex.: `agenda.zenim.me`).
   Depois abra o **Gerenciador de Arquivos** e anote a pasta do site — é a pasta que **contém** o `public_html`
   (ex.: `domains/agenda.zenim.me`).
2. **hPanel → Bancos de dados → MySQL** → crie o banco e o usuário (ex.: `u846229461_manicure`) e anote a senha.
3. Confira se o **PHP é 8.3** (hPanel → Avançado → Configuração do PHP).

## 2. Preencher `deploy\servidor.local.json` (fica só no seu PC)

O IP, a porta e o usuário SSH já vieram preenchidos (são os mesmos do portal). Troque só o que está em maiúsculas:

```json
{
  "host": "149.62.37.243",
  "port": 65002,
  "user": "u846229461",
  "app_dir": "domains/agenda.zenim.me",
  "site": "https://agenda.zenim.me",
  "db_name": "u846229461_manicure",
  "db_user": "u846229461_manicure"
}
```

## 3. Chave SSH

É a mesma da conta Hostinger do portal. Se você já publicou o portal neste PC, a agenda usa a chave
`%USERPROFILE%\.ssh\zenim_deploy` sozinha. Se não, copie
`C:\InfotecSoft-Treinamentos\deploy\CHAVE-PRIVADA-GITHUB.txt` para `C:\Manicure-Agenda\deploy\`.

## 4. Publicar

Dois cliques em **`publicar-hostinger.bat`**.
- Na primeira vez ele pede a **senha do banco** (não aparece na tela).
- No fim mostra **PUBLICADO!** com o endereço.
- A senha `123` não funciona na internet: rode **`definir-senha-admin.bat`** para criar a senha do painel.

Senha do banco errada? `publicar-hostinger.bat senha` apaga a configuração do servidor; depois publique de novo.

## 5. GitHub (opcional, para guardar as versões)

1. Crie o repositório **privado** `Manicure-Agenda` em https://github.com/new (sem README).
2. Dois cliques em **`conectar-github.bat`** (uma vez).
3. No dia a dia, o próprio `publicar-hostinger.bat` já salva a versão no GitHub antes de publicar.
   O workflow `.github/workflows/deploy.yml` fica só no modo manual, como no portal.

## Banco de dados

- Mudança de estrutura = novo arquivo `database/migrations/003_....sql`. O publicar aplica sozinho.
- Os agendamentos reais ficam só no servidor; o banco do seu PC é separado (teste).
