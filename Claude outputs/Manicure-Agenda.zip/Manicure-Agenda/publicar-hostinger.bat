@echo off
cd /d "%~dp0"
title Publicar a Agenda da Manicure
set "GIT_CONFIG_COUNT=1"
set "GIT_CONFIG_KEY_0=safe.directory"
set "GIT_CONFIG_VALUE_0=C:/Manicure-Agenda"
set "GIT="
where git >nul 2>nul && set "GIT=git"
if not defined GIT if exist "C:\Program Files\Git\cmd\git.exe" set "GIT=C:\Program Files\Git\cmd\git.exe"
if not defined GIT if exist "C:\laragon\bin\git\cmd\git.exe" set "GIT=C:\laragon\bin\git\cmd\git.exe"
if /i "%~1"=="senha" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0publicar-hostinger.ps1" -ApagarEnv
  pause
  exit /b
)
if defined GIT if exist ".git" (
  echo ==^> Salvando versao no GitHub
  if not exist ".github\workflows" mkdir ".github\workflows"
  copy /y "deploy\deploy.yml" ".github\workflows\deploy.yml" >nul
  "%GIT%" add -A
  "%GIT%" commit -q -m "Atualizacao da agenda %date% %time:~0,5%"
  "%GIT%" -c credential.helper= -c credential.helper=manager push -q
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0publicar-hostinger.ps1"
echo.
pause
