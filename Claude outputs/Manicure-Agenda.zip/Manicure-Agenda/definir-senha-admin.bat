@echo off
cd /d "%~dp0"
title Definir senha da agenda (site no ar)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0definir-senha-admin.ps1"
echo.
pause
