# Guia do projeto para IAs — Agenda da Manicure

> Leia antes de mexer no código. Mesmo padrão do **InfotecSoft Treinamentos** e do **Stok Net (sistema-pdv-main)**.
> Idioma: **português (Brasil)** para mensagens, labels e comentários; nomes de código (classes, métodos, colunas) em inglês.

## O que é

Site de agendamento online para manicure: a cliente escolhe o **serviço**, vê um **calendário com os dias que têm vaga**,
escolhe um **horário livre** e confirma com nome + WhatsApp. A manicure tem um **painel** (`/#painel`) com agenda do dia/semana,
serviços, horário de funcionamento, folgas/bloqueios e dados do salão.

## Stack

- **PHP 8.3** puro, MVC próprio em `app/Core` (copiado do InfotecSoft: `Route`, `Request`, `Controller`, `DB`, `QueryBuilder`, `Auth`, `CSRF`, `RateLimiter`, `View`).
- **MySQL** (Laragon) via PDO. Banco: `manicure` (`DB_DATABASE` no `.env`).
- Composer é **opcional** (o `bootstrap.php` tem autoload PSR-4 e leitor de `.env` próprios).
- **Front-end**: página única em `app/Views/app.html` (HTML/CSS/JS inline, sem npm). Fala com a API `/api/*` via `fetch` com header `X-CSRF-TOKEN` (o token vem no `GET /api/state`).

## Como rodar

1. Laragon com **MySQL ligado**.
2. **`iniciar-servidor.bat`** → cria o `.env` (copiando a conexão do sistema-pdv, banco `manicure`, porta **8002**), roda `database/scripts/run_all.php` e abre http://localhost:8002.
3. (opcional) **`popular-banco-teste.bat`** → agendamentos de teste nos próximos 10 dias.
4. Painel: http://localhost:8002/#painel — login inicial **admin / 123** (o sistema obriga a trocar no primeiro acesso).

## Fluxo de uma requisição

```
public_html/index.php → bootstrap.php (autoload, .env, helpers, headers/CSP, sessão) → routes/web.php
→ Route::dispatch() (CSRF em POST) → Controller → Service → Repository → DB::table()/DB::select() → MySQL
```
- `GET /` entrega `app/Views/app.html`. Tudo o mais é JSON (`json_out()` / `json_fail()` em `app/Helpers/api.php`).
- `require_login()` = exige login (401) e que a senha inicial já tenha sido trocada (403 `must_change`). `require_login(false)` só exige login (leituras).

## API

| Rota | Controller | Acesso |
|---|---|---|
| `GET /api/state` | StateController — salão, serviços, horário, csrf e (logada) usuária + configurações | público |
| `GET /api/calendar?month=AAAA-MM&service=ID` | AvailabilityController — situação de cada dia (`livre`, `lotado`, `fechado`, `passado`, `fora`) e nº de vagas | público |
| `GET /api/slots?date=AAAA-MM-DD&service=ID[&panel=1]` | AvailabilityController — horários livres (`panel=1` + logada = sem regra de antecedência) | público |
| `POST /api/bookings` | BookingController::store — cliente agenda (rate limit 6/h por IP, máx. 3 futuros por telefone) | público |
| `POST /api/login`, `/api/logout`, `/api/password` | AuthController (rate limit 5/15 min) | — / login |
| `GET /api/admin/bookings?from=&to=` | BookingController::index (até 3 meses) | login |
| `POST /api/admin/bookings` | BookingController::adminStore (`force=1` = encaixe fora da grade, nunca por cima de outra cliente) | login |
| `POST /api/admin/bookings/{id}/status` | `confirmado` / `concluido` / `cancelado` / `faltou` | login |
| `POST /api/admin/services`, `/{id}/delete` | AdminController (serviço com histórico só é desativado) | login |
| `POST /api/admin/hours` | AdminController — os 7 dias de uma vez | login |
| `GET/POST /api/admin/blocks`, `/{id}/delete` | AdminController — folgas/feriados (dia inteiro ou faixa de horário, vários dias) | login |
| `POST /api/admin/settings` | AdminController — nome, WhatsApp, endereço, regras da agenda | login |

## Regra dos horários livres (`AvailabilityService`)

Para um dia e um serviço de duração D, gera horários de `slot_interval` em `slot_interval` minutos entre a abertura e
(fechamento − D). Um horário só é livre se [início, início + D) **não encosta** em: intervalo do dia, bloqueios
(`blocks`) e agendamentos não cancelados. No site também valem `min_advance_hours` e `max_days_ahead`.
A gravação (`BookingService::create`) usa `GET_LOCK('manicure_booking')` e **confere de novo** antes de inserir — duas
clientes não pegam o mesmo horário.

## Banco de dados

Tabelas: `settings` (chave/valor), `services`, `working_hours` (0 = domingo … 6 = sábado), `blocks`, `bookings`, `users`, `migrations`.
- Alteração nova = `database/migrations/NNN_descricao.sql` com o próximo número (último: `002`). Rode `atualizar-banco.bat`.
- **Não use `;` dentro de textos** nas migrations (o `migrate.php` divide o arquivo por `;`). Não edite migration já aplicada.
- `bookings` guarda cópia de nome/preço/duração do serviço (o histórico não muda se o serviço for editado).

## Publicação

Igual ao InfotecSoft: `publicar-hostinger.bat` empacota, envia por SSH para a Hostinger, grava o `.env` do servidor
(pede a senha do banco só na primeira vez), roda migrations + `tests/smoke.php` e confere `/api/state`.
Dados do servidor em `deploy/servidor.local.json` (fora do Git). Detalhes no `DEPLOY.md`.

## Cuidados

- Não exibir/commitar o `.env` nem `deploy/servidor.local.json` / chave SSH.
- `display_errors` está **0** (a API sempre responde JSON); erros vão para o log do PHP.
- Senhas com `password_hash()`; sessão `manicure_sid` (HttpOnly, SameSite=Lax). Senha `123` do admin é recusada fora do localhost.
- Fuso: `America/Sao_Paulo` (bootstrap).
