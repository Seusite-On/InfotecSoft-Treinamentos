-- =============================================================
-- Agenda da Manicure - estrutura inicial
-- Padrão: um arquivo .sql por alteração, aplicado pelo database/scripts/migrate.php
-- (não use ponto e vírgula dentro de textos: o migrate divide o arquivo por ele)
-- =============================================================

-- Dados do salão (nome, WhatsApp, endereço, regras da agenda) em chave/valor
CREATE TABLE IF NOT EXISTS settings (
    setting_key   VARCHAR(60)  NOT NULL,
    setting_value TEXT         NULL,
    updated_at    DATETIME     NULL,
    PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS services (
    service_id   INT           NOT NULL AUTO_INCREMENT,
    name         VARCHAR(80)   NOT NULL,
    description  VARCHAR(255)  NULL,
    price        DECIMAL(10,2) NOT NULL DEFAULT 0,
    duration_min INT           NOT NULL DEFAULT 60 COMMENT 'duração em minutos',
    position     INT           NOT NULL DEFAULT 0,
    active       TINYINT(1)    NOT NULL DEFAULT 1,
    created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME      NULL,
    PRIMARY KEY (service_id),
    KEY idx_services_active_position (active, position)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Horário de funcionamento por dia da semana (0 = domingo ... 6 = sábado)
CREATE TABLE IF NOT EXISTS working_hours (
    weekday     TINYINT    NOT NULL,
    active      TINYINT(1) NOT NULL DEFAULT 1,
    start_time  TIME       NOT NULL DEFAULT '09:00:00',
    end_time    TIME       NOT NULL DEFAULT '18:00:00',
    break_start TIME       NULL COMMENT 'início do intervalo (almoço)',
    break_end   TIME       NULL,
    PRIMARY KEY (weekday)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Folgas, feriados e horários bloqueados (sem start_time = dia inteiro)
CREATE TABLE IF NOT EXISTS blocks (
    block_id   INT          NOT NULL AUTO_INCREMENT,
    block_date DATE         NOT NULL,
    start_time TIME         NULL,
    end_time   TIME         NULL,
    reason     VARCHAR(120) NULL,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (block_id),
    KEY idx_blocks_date (block_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Agendamentos (nome/preço/duração do serviço são copiados para não mudar o histórico)
CREATE TABLE IF NOT EXISTS bookings (
    booking_id   INT           NOT NULL AUTO_INCREMENT,
    code         VARCHAR(8)    NOT NULL COMMENT 'código curto mostrado à cliente',
    service_id   INT           NULL,
    service_name VARCHAR(80)   NOT NULL,
    price        DECIMAL(10,2) NOT NULL DEFAULT 0,
    duration_min INT           NOT NULL,
    client_name  VARCHAR(100)  NOT NULL,
    client_phone VARCHAR(20)   NOT NULL COMMENT 'só dígitos, com DDD',
    notes        VARCHAR(255)  NULL,
    booking_date DATE          NOT NULL,
    start_time   TIME          NOT NULL,
    end_time     TIME          NOT NULL,
    status       ENUM('confirmado','concluido','cancelado','faltou') NOT NULL DEFAULT 'confirmado',
    source       ENUM('site','painel') NOT NULL DEFAULT 'site',
    created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME      NULL,
    PRIMARY KEY (booking_id),
    UNIQUE KEY uq_bookings_code (code),
    KEY idx_bookings_date_status (booking_date, status),
    KEY idx_bookings_phone (client_phone),
    CONSTRAINT fk_bookings_service FOREIGN KEY (service_id) REFERENCES services (service_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Quem acessa o painel (a manicure e, se quiser, uma ajudante)
CREATE TABLE IF NOT EXISTS users (
    user_id              INT          NOT NULL AUTO_INCREMENT,
    name                 VARCHAR(120) NOT NULL,
    username             VARCHAR(30)  NOT NULL,
    password             VARCHAR(255) NOT NULL COMMENT 'hash gerado por password_hash()',
    role                 ENUM('admin','user') NOT NULL DEFAULT 'admin',
    active               TINYINT(1)   NOT NULL DEFAULT 1,
    must_change_password TINYINT(1)   NOT NULL DEFAULT 0,
    last_login_at        DATETIME     NULL,
    created_at           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           DATETIME     NULL,
    PRIMARY KEY (user_id),
    UNIQUE KEY uq_users_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
