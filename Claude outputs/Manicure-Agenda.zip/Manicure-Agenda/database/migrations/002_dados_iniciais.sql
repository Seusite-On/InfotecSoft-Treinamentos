-- Dados iniciais (exemplo). Tudo pode ser alterado depois pelo painel.
-- (não use ponto e vírgula dentro de textos)

INSERT IGNORE INTO settings (setting_key, setting_value) VALUES
('salon_name', 'Studio de Unhas'),
('tagline', 'Unhas lindas, sem complicação. Escolha o serviço e reserve seu horário.'),
('whatsapp', '11999999999'),
('instagram', ''),
('address', 'Rua Exemplo, 123 - Centro'),
('slot_interval', '30'),
('min_advance_hours', '2'),
('max_days_ahead', '45'),
('booking_notice', 'Chegue 5 minutos antes. Para remarcar ou cancelar, chame no WhatsApp.');

INSERT INTO services (name, description, price, duration_min, position)
SELECT * FROM (
    SELECT 'Mão' AS name, 'Cutilagem e esmaltação tradicional' AS description, 35.00 AS price, 45 AS duration_min, 1 AS position UNION ALL
    SELECT 'Pé', 'Cutilagem e esmaltação tradicional', 40.00, 45, 2 UNION ALL
    SELECT 'Pé e mão', 'Combo completo com esmaltação tradicional', 70.00, 90, 3 UNION ALL
    SELECT 'Esmaltação em gel', 'Brilho e duração de até 3 semanas', 60.00, 60, 4 UNION ALL
    SELECT 'Alongamento em gel', 'Aplicação completa com acabamento', 150.00, 150, 5 UNION ALL
    SELECT 'Manutenção do alongamento', 'Manutenção a cada 15 a 21 dias', 100.00, 90, 6
) AS seed
WHERE NOT EXISTS (SELECT 1 FROM services);

INSERT IGNORE INTO working_hours (weekday, active, start_time, end_time, break_start, break_end) VALUES
(0, 0, '09:00:00', '13:00:00', NULL, NULL),
(1, 0, '09:00:00', '18:00:00', '12:00:00', '13:00:00'),
(2, 1, '09:00:00', '18:00:00', '12:00:00', '13:00:00'),
(3, 1, '09:00:00', '18:00:00', '12:00:00', '13:00:00'),
(4, 1, '09:00:00', '18:00:00', '12:00:00', '13:00:00'),
(5, 1, '09:00:00', '19:00:00', '12:00:00', '13:00:00'),
(6, 1, '08:00:00', '14:00:00', NULL, NULL)
