<?php
/**
 * Cria agendamentos de TESTE nos próximos dias (só para ver a agenda funcionando no PC).
 * Uso: popular-banco-teste.bat   (não use no servidor)
 */
require_once __DIR__ . '/../../bootstrap.php';

use App\Core\DB;
use App\Services\AvailabilityService;
use App\Services\BookingService;

$services = DB::table('services')->where('active', 1)->get();
if (!$services) { echo "Nenhum serviço cadastrado.\n"; exit(1); }
$clientes = ['Ana Paula', 'Beatriz Souza', 'Camila Rocha', 'Daniela Lima', 'Fernanda Alves', 'Gabriela Costa', 'Juliana Martins', 'Larissa Gomes', 'Mariana Dias', 'Patrícia Nunes'];
$svc = new BookingService();
$n = 0;
for ($i = 0; $i < 10; $i++) {
    $date = date('Y-m-d', strtotime("+$i days"));
    $per = random_int(1, 4);
    for ($k = 0; $k < $per; $k++) {
        $s = $services[array_rand($services)];
        $slots = (new AvailabilityService())->slots($date, (int) $s['duration_min'], false);
        if (!$slots) break;
        $r = $svc->create([
            'name' => $clientes[array_rand($clientes)],
            'phone' => '119' . random_int(10000000, 99999999),
            'service_id' => $s['service_id'],
            'date' => $date,
            'time' => $slots[array_rand($slots)],
            'notes' => '[TESTE]',
        ], true);
        if ($r['ok']) $n++;
    }
}
echo "$n agendamentos de teste criados nos próximos 10 dias.\n";
