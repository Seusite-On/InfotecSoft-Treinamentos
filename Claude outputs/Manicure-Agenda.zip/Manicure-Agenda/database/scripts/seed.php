<?php
/**
 * Garante o acesso principal do painel (usuário "admin").
 * Só cria se ainda não existir — nunca troca a senha de um admin já cadastrado.
 */
require_once __DIR__ . '/../../bootstrap.php';

use App\Core\DB;

$exists = DB::table('users')->where('username', 'admin')->first();
if ($exists) {
    echo "Administradora 'admin' já existe (senha mantida).\n";
    exit(0);
}
DB::table('users')->insert([
    'name' => 'Manicure',
    'username' => 'admin',
    'password' => password_hash('123', PASSWORD_DEFAULT),
    'role' => 'admin',
    'active' => 1,
    'must_change_password' => 1,
    'created_at' => date('Y-m-d H:i:s'),
]);
echo "Acesso criado: usuário 'admin' / senha '123' (troque a senha no primeiro acesso).\n";
