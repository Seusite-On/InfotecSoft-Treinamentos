<?php

/** Responde JSON e encerra (padrão das rotas /api). */
if (!function_exists('json_out')) {
    function json_out(array $data, int $status = 200): never
    {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store');
        }
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

if (!function_exists('json_fail')) {
    function json_fail(string $message, int $status = 422, array $extra = []): never
    {
        json_out(['ok' => false, 'message' => $message] + $extra, $status);
    }
}

/**
 * Exige login da equipe (401). Com $strict = true também exige que a senha
 * inicial já tenha sido trocada (403) — usado em todas as ações de alteração.
 */
if (!function_exists('require_login')) {
    function require_login(bool $strict = true): array
    {
        if (!\App\Core\Auth::check()) {
            json_fail('Sua sessão expirou. Entre novamente.', 401);
        }
        $row = \App\Core\DB::table('users')->select('active')->where('user_id', (int) \App\Core\Auth::id())->first();
        if (!$row || (int) $row['active'] !== 1) {
            \App\Core\Auth::logout();
            json_fail('Seu acesso não está mais ativo.', 401);
        }
        if ($strict && !empty($_SESSION['must_change'])) {
            json_fail('Troque sua senha em "Minha senha" antes de continuar.', 403, ['code' => 'must_change']);
        }
        return \App\Core\Auth::user();
    }
}

if (!function_exists('now')) {
    function now(): string
    {
        return date('Y-m-d H:i:s');
    }
}

/** "09:30" -> 570 (minutos desde 00:00) */
if (!function_exists('to_min')) {
    function to_min(?string $hhmm): ?int
    {
        if ($hhmm === null || $hhmm === '') return null;
        if (!preg_match('/^(\d{1,2}):(\d{2})/', $hhmm, $m)) return null;
        return (int) $m[1] * 60 + (int) $m[2];
    }
}

/** 570 -> "09:30" */
if (!function_exists('to_hhmm')) {
    function to_hhmm(int $min): string
    {
        return sprintf('%02d:%02d', intdiv($min, 60), $min % 60);
    }
}

/** Data válida no formato AAAA-MM-DD */
if (!function_exists('valid_date')) {
    function valid_date(string $d): bool
    {
        $dt = \DateTime::createFromFormat('!Y-m-d', $d);
        return $dt !== false && $dt->format('Y-m-d') === $d;
    }
}

/** Telefone só com dígitos (com DDD). */
if (!function_exists('only_digits')) {
    function only_digits(string $v): string
    {
        return preg_replace('/\D/', '', $v);
    }
}

if (!function_exists('format_phone')) {
    function format_phone(string $d): string
    {
        if (strlen($d) === 11) return preg_replace('/(\d{2})(\d{5})(\d{4})/', '($1) $2-$3', $d);
        if (strlen($d) === 10) return preg_replace('/(\d{2})(\d{4})(\d{4})/', '($1) $2-$3', $d);
        return $d;
    }
}
