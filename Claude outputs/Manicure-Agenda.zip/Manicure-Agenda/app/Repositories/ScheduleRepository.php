<?php

namespace App\Repositories;

use App\Core\DB;

/** Horário de funcionamento (working_hours) e bloqueios (blocks). */
class ScheduleRepository
{
    /** @return array<int,array> indexado pelo dia da semana (0 = domingo) */
    public function hours(): array
    {
        $out = [];
        foreach (DB::table('working_hours')->orderBy('weekday')->get() as $r) {
            $out[(int) $r['weekday']] = $r;
        }
        return $out;
    }

    public function saveHour(int $weekday, array $data): void
    {
        DB::statement(
            'INSERT INTO working_hours (weekday, active, start_time, end_time, break_start, break_end) VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE active = VALUES(active), start_time = VALUES(start_time), end_time = VALUES(end_time),
             break_start = VALUES(break_start), break_end = VALUES(break_end)',
            [$weekday, $data['active'], $data['start_time'], $data['end_time'], $data['break_start'], $data['break_end']]
        );
    }

    public function blocksBetween(string $from, string $to): array
    {
        return DB::select('SELECT * FROM blocks WHERE block_date BETWEEN ? AND ? ORDER BY block_date, start_time', [$from, $to]);
    }

    public function upcomingBlocks(): array
    {
        return DB::select('SELECT * FROM blocks WHERE block_date >= ? ORDER BY block_date, start_time', [date('Y-m-d')]);
    }

    public function addBlock(array $data): int
    {
        $data['created_at'] = now();
        return (int) DB::table('blocks')->insert($data);
    }

    public function deleteBlock(int $id): int
    {
        return DB::table('blocks')->where('block_id', $id)->delete();
    }
}
