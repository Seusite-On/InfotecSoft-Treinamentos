<?php

namespace App\Repositories;

use App\Core\DB;

class BookingRepository
{
    /** Agendamentos que ocupam a agenda (não cancelados) entre duas datas. */
    public function activeBetween(string $from, string $to): array
    {
        return DB::select(
            "SELECT booking_date, start_time, end_time FROM bookings WHERE booking_date BETWEEN ? AND ? AND status <> 'cancelado'",
            [$from, $to]
        );
    }

    public function listBetween(string $from, string $to): array
    {
        return DB::select('SELECT * FROM bookings WHERE booking_date BETWEEN ? AND ? ORDER BY booking_date, start_time', [$from, $to]);
    }

    public function find(int $id): ?array
    {
        return DB::table('bookings')->where('booking_id', $id)->first();
    }

    public function countFutureByPhone(string $phone): int
    {
        $r = DB::select(
            "SELECT COUNT(*) AS n FROM bookings WHERE client_phone = ? AND status = 'confirmado' AND booking_date >= ?",
            [$phone, date('Y-m-d')]
        );
        return (int) ($r[0]['n'] ?? 0);
    }

    public function codeExists(string $code): bool
    {
        return (bool) DB::table('bookings')->where('code', $code)->first();
    }

    public function create(array $data): int
    {
        $data['created_at'] = now();
        return (int) DB::table('bookings')->insert($data);
    }

    public function update(int $id, array $data): void
    {
        $data['updated_at'] = now();
        DB::table('bookings')->where('booking_id', $id)->update($data);
    }
}
