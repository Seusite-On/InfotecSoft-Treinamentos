<?php

namespace App\Repositories;

use App\Core\DB;

class ServiceRepository
{
    public function all(bool $onlyActive = false): array
    {
        $q = DB::table('services')->orderBy('position')->orderBy('service_id');
        if ($onlyActive) $q->where('active', 1);
        return $q->get();
    }

    public function find(int $id): ?array
    {
        return DB::table('services')->where('service_id', $id)->first();
    }

    public function create(array $data): int
    {
        $data['position'] = (int) (DB::select('SELECT COALESCE(MAX(position), 0) + 1 AS p FROM services')[0]['p'] ?? 1);
        $data['created_at'] = now();
        return (int) DB::table('services')->insert($data);
    }

    public function update(int $id, array $data): void
    {
        $data['updated_at'] = now();
        DB::table('services')->where('service_id', $id)->update($data);
    }

    public function hasBookings(int $id): bool
    {
        return DB::table('bookings')->where('service_id', $id)->count() > 0;
    }

    public function delete(int $id): void
    {
        DB::table('services')->where('service_id', $id)->delete();
    }
}
