<?php

namespace App\Repositories;

use App\Core\DB;

class UserRepository
{
    public function findByLogin(string $login): ?array
    {
        $rows = DB::select('SELECT * FROM users WHERE LOWER(username) = LOWER(?) LIMIT 1', [$login]);
        return $rows[0] ?? null;
    }

    public function find(int $id): ?array
    {
        return DB::table('users')->where('user_id', $id)->first();
    }

    public function create(array $data): int
    {
        return (int) DB::table('users')->insert($data);
    }

    public function update(int $id, array $data): void
    {
        DB::table('users')->where('user_id', $id)->update($data);
    }
}
