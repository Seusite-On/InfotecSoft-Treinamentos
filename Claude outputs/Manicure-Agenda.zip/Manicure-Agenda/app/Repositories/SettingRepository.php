<?php

namespace App\Repositories;

use App\Core\DB;

class SettingRepository
{
    /** Valores padrão (usados se a chave ainda não existir no banco). */
    public const DEFAULTS = [
        'salon_name' => 'Studio de Unhas',
        'tagline' => '',
        'whatsapp' => '',
        'instagram' => '',
        'address' => '',
        'slot_interval' => '30',
        'min_advance_hours' => '2',
        'max_days_ahead' => '45',
        'booking_notice' => '',
    ];

    public function all(): array
    {
        $out = self::DEFAULTS;
        foreach (DB::select('SELECT setting_key, setting_value FROM settings') as $r) {
            if (array_key_exists($r['setting_key'], $out)) {
                $out[$r['setting_key']] = (string) $r['setting_value'];
            }
        }
        return $out;
    }

    public function int(string $key): int
    {
        return (int) ($this->all()[$key] ?? 0);
    }

    public function save(array $values): void
    {
        foreach ($values as $k => $v) {
            if (!array_key_exists($k, self::DEFAULTS)) continue;
            DB::statement(
                'INSERT INTO settings (setting_key, setting_value, updated_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)',
                [$k, (string) $v, now()]
            );
        }
    }
}
