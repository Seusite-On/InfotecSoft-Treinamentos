<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Request;
use App\Repositories\ServiceRepository;
use App\Services\AvailabilityService;

/** Calendário público: GET /api/calendar?month=2026-11&service=3  e  GET /api/slots?date=2026-11-20&service=3 */
class AvailabilityController extends Controller
{
    private Request $request;

    public function __construct()
    {
        $this->request = new Request();
    }

    public function calendar(): void
    {
        $month = $this->request->string('month');
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month)) json_fail('Mês inválido.');
        $svc = $this->service();
        json_out(['ok' => true, 'month' => $month, 'days' => (new AvailabilityService())->month($month, (int) $svc['duration_min'])]);
    }

    public function slots(): void
    {
        $date = $this->request->string('date');
        if (!valid_date($date)) json_fail('Data inválida.');
        $svc = $this->service();
        // No painel (logada e pedindo ?panel=1) mostra a grade sem as regras de antecedência
        $panel = $this->request->string('panel') === '1' && Auth::check();
        json_out(['ok' => true, 'date' => $date, 'slots' => (new AvailabilityService())->slots($date, (int) $svc['duration_min'], !$panel)]);
    }

    private function service(): array
    {
        $svc = (new ServiceRepository())->find($this->request->int('service'));
        if (!$svc || (!(int) $svc['active'] && !Auth::check())) json_fail('Escolha um serviço.');
        return $svc;
    }
}
