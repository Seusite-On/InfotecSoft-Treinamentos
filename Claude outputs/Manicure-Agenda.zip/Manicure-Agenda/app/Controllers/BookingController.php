<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Repositories\BookingRepository;
use App\Services\BookingService;

class BookingController extends Controller
{
    private Request $request;

    public function __construct()
    {
        $this->request = new Request();
    }

    /** Cliente agenda pelo site (POST /api/bookings). */
    public function store(): void
    {
        $limiter = new RateLimiter();
        $key = 'booking:' . hash('sha256', $this->request->clientIp());
        if ($limiter->tooManyAttempts($key, 6, 3600)) {
            json_fail('Muitos agendamentos feitos desta rede. Tente mais tarde ou chame no WhatsApp.', 429, ['code' => 'locked']);
        }
        $r = (new BookingService())->create($this->request->all());
        if ($r['ok']) $limiter->hit($key, 3600);
        $status = $r['status'];
        unset($r['status']);
        json_out($r, $status);
    }

    /** Painel: lista entre datas (GET /api/admin/bookings?from=2026-11-01&to=2026-11-30). */
    public function index(): void
    {
        require_login(false);
        $from = $this->request->string('from');
        $to = $this->request->string('to');
        if (!valid_date($from) || !valid_date($to) || $to < $from) json_fail('Período inválido.');
        if ((strtotime($to) - strtotime($from)) / 86400 > 92) json_fail('Escolha um período de até 3 meses.');
        $rows = (new BookingRepository())->listBetween($from, $to);
        json_out(['ok' => true, 'bookings' => array_map([BookingService::class, 'present'], $rows)]);
    }

    /** Painel: a manicure marca para uma cliente (WhatsApp/telefone). force=1 = encaixe fora da grade. */
    public function adminStore(): void
    {
        require_login();
        $r = (new BookingService())->create($this->request->all(), true, $this->request->boolean('force'));
        $status = $r['status'];
        unset($r['status']);
        json_out($r, $status);
    }

    public function status(string $id): void
    {
        require_login();
        $r = (new BookingService())->setStatus((int) $id, $this->request->string('status'));
        $status = $r['status'];
        unset($r['status']);
        json_out($r, $status);
    }
}
