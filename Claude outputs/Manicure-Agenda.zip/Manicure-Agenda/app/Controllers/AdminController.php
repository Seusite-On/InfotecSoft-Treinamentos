<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\DB;
use App\Core\Request;
use App\Repositories\ScheduleRepository;
use App\Repositories\ServiceRepository;
use App\Repositories\SettingRepository;

/** Painel da manicure: serviços, horário de funcionamento, bloqueios e configurações. */
class AdminController extends Controller
{
    private Request $request;

    public function __construct()
    {
        $this->request = new Request();
    }

    /* ---------------- Serviços ---------------- */

    public function saveService(): void
    {
        require_login();
        $id = $this->request->int('id');
        $name = preg_replace('/\s+/', ' ', $this->request->string('name'));
        $desc = $this->request->string('description');
        $price = (float) str_replace(',', '.', $this->request->string('price'));
        $dur = $this->request->int('duration');
        $e = [];
        if (mb_strlen($name) < 2 || mb_strlen($name) > 80) $e['name'] = 'Nome do serviço com 2 a 80 caracteres.';
        if (mb_strlen($desc) > 255) $e['description'] = 'Descrição com no máximo 255 caracteres.';
        if ($price < 0 || $price > 99999) $e['price'] = 'Preço inválido.';
        if ($dur < 10 || $dur > 600 || $dur % 5 !== 0) $e['duration'] = 'Duração entre 10 e 600 minutos (de 5 em 5).';
        if ($e) json_out(['ok' => false, 'errors' => $e, 'message' => 'Confira os campos destacados.'], 422);

        $repo = new ServiceRepository();
        $data = ['name' => $name, 'description' => $desc !== '' ? $desc : null, 'price' => round($price, 2), 'duration_min' => $dur, 'active' => $this->request->boolean('active', true) ? 1 : 0];
        if ($id) {
            if (!$repo->find($id)) json_fail('Serviço não encontrado.', 404);
            $repo->update($id, $data);
        } else {
            $id = $repo->create($data);
        }
        json_out(['ok' => true, 'id' => $id]);
    }

    public function deleteService(string $id): void
    {
        require_login();
        $repo = new ServiceRepository();
        $id = (int) $id;
        if (!$repo->find($id)) json_fail('Serviço não encontrado.', 404);
        if ($repo->hasBookings($id)) {
            // Mantém o histórico: só esconde do site
            $repo->update($id, ['active' => 0]);
            json_out(['ok' => true, 'deactivated' => true, 'message' => 'O serviço tem agendamentos no histórico, então foi apenas desativado (não aparece mais no site).']);
        }
        $repo->delete($id);
        json_out(['ok' => true]);
    }

    /* ---------------- Horário de funcionamento ---------------- */

    public function saveHours(): void
    {
        require_login();
        $days = $this->request->input('days', []);
        if (!is_array($days) || count($days) !== 7) json_fail('Envie os 7 dias da semana.');
        $clean = [];
        $names = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
        foreach ($days as $d) {
            $wd = (int) ($d['weekday'] ?? -1);
            if ($wd < 0 || $wd > 6 || isset($clean[$wd])) json_fail('Dia da semana inválido.');
            $active = !empty($d['active']);
            $s = to_min((string) ($d['start'] ?? ''));
            $en = to_min((string) ($d['end'] ?? ''));
            $bs = to_min((string) ($d['break_start'] ?? ''));
            $be = to_min((string) ($d['break_end'] ?? ''));
            if ($active) {
                if ($s === null || $en === null || $en <= $s) json_fail("{$names[$wd]}: o horário de fechar precisa ser depois do de abrir.");
                if (($bs === null) !== ($be === null)) json_fail("{$names[$wd]}: preencha início e fim do intervalo (ou deixe os dois vazios).");
                if ($bs !== null && ($be <= $bs || $bs < $s || $be > $en)) json_fail("{$names[$wd]}: o intervalo precisa ficar dentro do expediente.");
            }
            $clean[$wd] = [
                'active' => $active ? 1 : 0,
                'start_time' => to_hhmm($s ?? 540) . ':00',
                'end_time' => to_hhmm($en ?? 1080) . ':00',
                'break_start' => $bs !== null ? to_hhmm($bs) . ':00' : null,
                'break_end' => $be !== null ? to_hhmm($be) . ':00' : null,
            ];
        }
        $repo = new ScheduleRepository();
        foreach ($clean as $wd => $data) $repo->saveHour($wd, $data);
        json_out(['ok' => true]);
    }

    /* ---------------- Bloqueios (folga, feriado, compromisso) ---------------- */

    public function blocks(): void
    {
        require_login(false);
        $rows = (new ScheduleRepository())->upcomingBlocks();
        json_out(['ok' => true, 'blocks' => array_map(static fn($b) => [
            'id' => (int) $b['block_id'],
            'date' => $b['block_date'],
            'start' => $b['start_time'] ? substr($b['start_time'], 0, 5) : null,
            'end' => $b['end_time'] ? substr($b['end_time'], 0, 5) : null,
            'reason' => $b['reason'],
        ], $rows)]);
    }

    public function addBlock(): void
    {
        require_login();
        $date = $this->request->string('date');
        $until = $this->request->string('until') ?: $date;
        $s = to_min($this->request->string('start'));
        $en = to_min($this->request->string('end'));
        $reason = mb_substr($this->request->string('reason'), 0, 120);
        if (!valid_date($date) || !valid_date($until) || $until < $date) json_fail('Escolha a(s) data(s) do bloqueio.');
        if ((strtotime($until) - strtotime($date)) / 86400 > 60) json_fail('Bloqueie no máximo 60 dias de uma vez.');
        if (($s === null) !== ($en === null) || ($s !== null && $en <= $s)) json_fail('Informe início e fim do horário (ou deixe vazio para bloquear o dia todo).');

        $repo = new ScheduleRepository();
        $n = 0;
        for ($d = $date; $d <= $until; $d = date('Y-m-d', strtotime($d . ' +1 day'))) {
            $repo->addBlock([
                'block_date' => $d,
                'start_time' => $s !== null ? to_hhmm($s) . ':00' : null,
                'end_time' => $en !== null ? to_hhmm($en) . ':00' : null,
                'reason' => $reason !== '' ? $reason : null,
            ]);
            $n++;
        }
        // Avisa se já existem clientes marcadas no período bloqueado (não cancela sozinho)
        $sql = "SELECT COUNT(*) AS n FROM bookings WHERE status = 'confirmado' AND booking_date BETWEEN ? AND ?";
        $bind = [$date, $until];
        if ($s !== null) {
            $sql .= ' AND start_time < ? AND end_time > ?';
            $bind[] = to_hhmm($en) . ':00';
            $bind[] = to_hhmm($s) . ':00';
        }
        $conflicts = (int) (DB::select($sql, $bind)[0]['n'] ?? 0);
        json_out(['ok' => true, 'created' => $n, 'conflicts' => $conflicts]);
    }

    public function deleteBlock(string $id): void
    {
        require_login();
        if (!(new ScheduleRepository())->deleteBlock((int) $id)) json_fail('Bloqueio não encontrado.', 404);
        json_out(['ok' => true]);
    }

    /* ---------------- Configurações do salão ---------------- */

    public function saveSettings(): void
    {
        require_login();
        $in = $this->request->all();
        $v = [
            'salon_name' => trim((string) ($in['salon_name'] ?? '')),
            'tagline' => trim((string) ($in['tagline'] ?? '')),
            'whatsapp' => only_digits((string) ($in['whatsapp'] ?? '')),
            'instagram' => ltrim(trim((string) ($in['instagram'] ?? '')), '@'),
            'address' => trim((string) ($in['address'] ?? '')),
            'slot_interval' => (int) ($in['slot_interval'] ?? 30),
            'min_advance_hours' => (int) ($in['min_advance_hours'] ?? 2),
            'max_days_ahead' => (int) ($in['max_days_ahead'] ?? 45),
            'booking_notice' => trim((string) ($in['booking_notice'] ?? '')),
        ];
        $e = [];
        if (mb_strlen($v['salon_name']) < 2 || mb_strlen($v['salon_name']) > 80) $e['salon_name'] = 'Nome com 2 a 80 caracteres.';
        if (mb_strlen($v['tagline']) > 200) $e['tagline'] = 'Máximo de 200 caracteres.';
        if ($v['whatsapp'] !== '' && (strlen($v['whatsapp']) < 10 || strlen($v['whatsapp']) > 13)) $e['whatsapp'] = 'WhatsApp com DDD (ex.: 11 91234-5678).';
        if ($v['instagram'] !== '' && !preg_match('/^[A-Za-z0-9._]{1,30}$/', $v['instagram'])) $e['instagram'] = 'Só o usuário do Instagram (ex.: studiodeunhas).';
        if (mb_strlen($v['address']) > 200) $e['address'] = 'Máximo de 200 caracteres.';
        if (!in_array($v['slot_interval'], [10, 15, 20, 30, 45, 60], true)) $e['slot_interval'] = 'Intervalo inválido.';
        if ($v['min_advance_hours'] < 0 || $v['min_advance_hours'] > 72) $e['min_advance_hours'] = 'Entre 0 e 72 horas.';
        if ($v['max_days_ahead'] < 7 || $v['max_days_ahead'] > 180) $e['max_days_ahead'] = 'Entre 7 e 180 dias.';
        if (mb_strlen($v['booking_notice']) > 300) $e['booking_notice'] = 'Máximo de 300 caracteres.';
        if ($e) json_out(['ok' => false, 'errors' => $e, 'message' => 'Confira os campos destacados.'], 422);
        (new SettingRepository())->save($v);
        json_out(['ok' => true]);
    }
}
