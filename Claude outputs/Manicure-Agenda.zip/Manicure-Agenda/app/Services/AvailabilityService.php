<?php

namespace App\Services;

use App\Repositories\BookingRepository;
use App\Repositories\ScheduleRepository;
use App\Repositories\SettingRepository;

/**
 * Calcula os horários livres.
 * Regra: um horário está livre se o serviço inteiro (início + duração) cabe no expediente do dia,
 * não encosta no intervalo de almoço, em bloqueios nem em outro agendamento não cancelado.
 */
class AvailabilityService
{
    private array $settings;
    private array $hours;

    public function __construct(
        private ScheduleRepository $schedule = new ScheduleRepository(),
        private BookingRepository $bookings = new BookingRepository(),
        SettingRepository $settings = new SettingRepository(),
    ) {
        $this->settings = $settings->all();
        $this->hours = $this->schedule->hours();
    }

    /** Primeiro e último dia que a cliente pode agendar pelo site. */
    public function window(): array
    {
        $max = max(1, (int) $this->settings['max_days_ahead']);
        return [date('Y-m-d'), date('Y-m-d', strtotime("+$max days"))];
    }

    /**
     * Situação de cada dia do mês para um serviço.
     * @return array<string,array{status:string,free:int}> status: passado | fechado | lotado | livre | fora
     */
    public function month(string $ym, int $duration): array
    {
        $first = $ym . '-01';
        $last = date('Y-m-t', strtotime($first));
        [$minDay, $maxDay] = $this->window();
        $ctx = $this->context($first, $last);
        $out = [];
        for ($d = $first; $d <= $last; $d = date('Y-m-d', strtotime($d . ' +1 day'))) {
            if ($d < $minDay) {
                $out[$d] = ['status' => 'passado', 'free' => 0];
                continue;
            }
            if ($d > $maxDay) {
                $out[$d] = ['status' => 'fora', 'free' => 0];
                continue;
            }
            $h = $this->hours[(int) date('w', strtotime($d))] ?? null;
            if (!$h || !(int) $h['active'] || $this->fullDayBlocked($d, $ctx['blocks'])) {
                $out[$d] = ['status' => 'fechado', 'free' => 0];
                continue;
            }
            $n = count($this->freeSlots($d, $duration, $ctx, true));
            $out[$d] = ['status' => $n ? 'livre' : 'lotado', 'free' => $n];
        }
        return $out;
    }

    /**
     * Horários livres ("HH:MM") de um dia.
     * $publicRules = true aplica antecedência mínima e limite de dias (site). O painel usa false.
     */
    public function slots(string $date, int $duration, bool $publicRules = true): array
    {
        if ($publicRules) {
            [$minDay, $maxDay] = $this->window();
            if ($date < $minDay || $date > $maxDay) return [];
        }
        return $this->freeSlots($date, $duration, $this->context($date, $date), $publicRules);
    }

    public function isFree(string $date, string $hhmm, int $duration, bool $publicRules = true): bool
    {
        return in_array($hhmm, $this->slots($date, $duration, $publicRules), true);
    }

    /** O intervalo [início, fim) não bate em nenhum agendamento ativo (usado nos encaixes do painel). */
    public function noBookingConflict(string $date, int $start, int $end): bool
    {
        foreach ($this->bookings->activeBetween($date, $date) as $b) {
            if ($start < to_min($b['end_time']) && $end > to_min($b['start_time'])) return false;
        }
        return true;
    }

    /* ---------------------------------------------------------------- */

    private function context(string $from, string $to): array
    {
        $byDay = static function (array $rows, string $col): array {
            $o = [];
            foreach ($rows as $r) $o[$r[$col]][] = $r;
            return $o;
        };
        return [
            'blocks' => $byDay($this->schedule->blocksBetween($from, $to), 'block_date'),
            'bookings' => $byDay($this->bookings->activeBetween($from, $to), 'booking_date'),
        ];
    }

    private function fullDayBlocked(string $date, array $blocks): bool
    {
        foreach ($blocks[$date] ?? [] as $b) {
            if ($b['start_time'] === null) return true;
        }
        return false;
    }

    private function freeSlots(string $date, int $duration, array $ctx, bool $publicRules): array
    {
        $h = $this->hours[(int) date('w', strtotime($date))] ?? null;
        if (!$h || !(int) $h['active'] || $duration <= 0) return [];
        if ($this->fullDayBlocked($date, $ctx['blocks'])) return [];

        $busy = [];
        if ($h['break_start'] !== null && $h['break_end'] !== null) {
            $busy[] = [to_min($h['break_start']), to_min($h['break_end'])];
        }
        foreach ($ctx['blocks'][$date] ?? [] as $b) {
            $busy[] = [to_min($b['start_time']), to_min($b['end_time'] ?? '23:59')];
        }
        foreach ($ctx['bookings'][$date] ?? [] as $b) {
            $busy[] = [to_min($b['start_time']), to_min($b['end_time'])];
        }

        $open = to_min($h['start_time']);
        $close = to_min($h['end_time']);
        $step = max(5, (int) $this->settings['slot_interval']);
        $earliest = -1;
        if ($date === date('Y-m-d')) {
            $nowMin = (int) date('G') * 60 + (int) date('i');
            $earliest = $nowMin + ($publicRules ? (int) $this->settings['min_advance_hours'] * 60 : 0);
        } elseif ($publicRules && $date < date('Y-m-d')) {
            return [];
        } elseif ($publicRules) {
            // antecedência que passa da meia-noite (ex.: 22h com 4 h de antecedência)
            $limit = time() + (int) $this->settings['min_advance_hours'] * 3600;
            if (date('Y-m-d', $limit) === $date) {
                $earliest = (int) date('G', $limit) * 60 + (int) date('i', $limit);
            }
        }

        $out = [];
        for ($t = $open; $t + $duration <= $close; $t += $step) {
            if ($t < $earliest) continue;
            $end = $t + $duration;
            $ok = true;
            foreach ($busy as [$bs, $be]) {
                if ($t < $be && $end > $bs) {
                    $ok = false;
                    break;
                }
            }
            if ($ok) $out[] = to_hhmm($t);
        }
        return $out;
    }
}
