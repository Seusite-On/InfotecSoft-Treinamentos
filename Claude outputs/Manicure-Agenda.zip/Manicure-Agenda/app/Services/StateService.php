<?php

namespace App\Services;

use App\Core\Auth;
use App\Core\CSRF;
use App\Repositories\ScheduleRepository;
use App\Repositories\ServiceRepository;
use App\Repositories\SettingRepository;

/** Tudo o que a página precisa ao abrir. Dados do painel só vão para quem está logada. */
class StateService
{
    public function build(): array
    {
        $settings = (new SettingRepository())->all();
        $logged = Auth::check();
        $services = (new ServiceRepository())->all(!$logged);
        $hours = [];
        foreach ((new ScheduleRepository())->hours() as $wd => $h) {
            $hours[] = [
                'weekday' => $wd,
                'active' => (bool) (int) $h['active'],
                'start' => substr($h['start_time'], 0, 5),
                'end' => substr($h['end_time'], 0, 5),
                'break_start' => $h['break_start'] ? substr($h['break_start'], 0, 5) : '',
                'break_end' => $h['break_end'] ? substr($h['break_end'], 0, 5) : '',
            ];
        }
        [$minDay, $maxDay] = (new AvailabilityService())->window();
        $out = [
            'ok' => true,
            'csrf' => CSRF::token(),
            'today' => date('Y-m-d'),
            'window' => ['from' => $minDay, 'to' => $maxDay],
            'salon' => [
                'name' => $settings['salon_name'],
                'tagline' => $settings['tagline'],
                'whatsapp' => $settings['whatsapp'],
                'instagram' => $settings['instagram'],
                'address' => $settings['address'],
                'notice' => $settings['booking_notice'],
            ],
            'services' => array_map(static fn($s) => [
                'id' => (int) $s['service_id'],
                'name' => $s['name'],
                'description' => (string) $s['description'],
                'price' => (float) $s['price'],
                'duration' => (int) $s['duration_min'],
                'active' => (bool) (int) $s['active'],
            ], $services),
            'hours' => $hours,
            'user' => null,
        ];
        if ($logged) {
            $u = Auth::user();
            $out['user'] = ['name' => $u['name'], 'username' => $u['username'], 'must_change' => !empty($_SESSION['must_change'])];
            $out['settings'] = $settings;
        }
        return $out;
    }
}
