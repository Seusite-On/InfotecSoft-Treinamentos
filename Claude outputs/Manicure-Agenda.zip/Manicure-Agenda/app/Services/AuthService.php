<?php

namespace App\Services;

use App\Core\Auth;
use App\Repositories\UserRepository;

class AuthService
{
    public function __construct(private UserRepository $users = new UserRepository()) {}

    /** @return array{ok:bool,status:int,code?:string,message?:string} */
    public function attempt(string $login, string $password): array
    {
        $u = $this->users->findByLogin($login);
        // Mesmo custo de tempo com ou sem usuário (evita descobrir logins válidos pelo tempo de resposta)
        $hash = $u ? (string) $u['password'] : '$2y$10$usesomesillystringfore7hnbRJHxXVLeakoG8K30oukPsA.ztMG';
        $okPw = password_verify($password, $hash);
        if (!$u || !$okPw) {
            return ['ok' => false, 'status' => 401, 'code' => 'invalid', 'message' => 'Usuário ou senha incorretos. Tente novamente.'];
        }
        if (!(int) $u['active']) {
            return ['ok' => false, 'status' => 403, 'code' => 'inactive', 'message' => 'Este acesso foi desativado.'];
        }
        // Senha padrão do administrador (123) só funciona no PC local. Na internet ela é recusada.
        $local = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true) && in_array(strtolower(explode(':', $_SERVER['HTTP_HOST'] ?? '')[0]), ['localhost', '127.0.0.1'], true);
        if ($u['role'] === 'admin' && hash_equals('123', $password) && !$local) {
            return ['ok' => false, 'status' => 403, 'code' => 'admin_default', 'message' => 'Por segurança, a senha padrão foi bloqueada na internet. Defina uma nova senha pelo arquivo definir-senha-admin.bat no seu PC.'];
        }
        if (password_needs_rehash((string) $u['password'], PASSWORD_DEFAULT)) {
            $this->users->update((int) $u['user_id'], ['password' => password_hash($password, PASSWORD_DEFAULT)]);
        }
        $this->users->update((int) $u['user_id'], ['last_login_at' => now()]);
        Auth::login(['user_id' => (int) $u['user_id'], 'name' => $u['name'], 'username' => $u['username'], 'role' => $u['role']]);
        // Senha inicial/fraca: obriga a troca antes de usar o painel
        $_SESSION['must_change'] = !password_is_strong($password) || !empty($u['must_change_password']);
        return ['ok' => true, 'status' => 200];
    }
}
