<?php

namespace App\Services;

use App\Core\DB;
use App\Repositories\BookingRepository;
use App\Repositories\ServiceRepository;

class BookingService
{
    public const STATUSES = ['confirmado', 'concluido', 'cancelado', 'faltou'];
    private const MAX_FUTURE_PER_PHONE = 3;

    public function __construct(
        private BookingRepository $bookings = new BookingRepository(),
        private ServiceRepository $services = new ServiceRepository(),
    ) {}

    /**
     * Cria um agendamento.
     * $fromPanel = true: feito pela manicure (ignora antecedência/limite de dias e o limite por telefone).
     * $force = true (só no painel): "encaixe" fora da grade de horários, mas nunca por cima de outro agendamento.
     */
    public function create(array $in, bool $fromPanel = false, bool $force = false): array
    {
        $v = [
            'name' => preg_replace('/\s+/', ' ', trim((string) ($in['name'] ?? ''))),
            'phone' => only_digits((string) ($in['phone'] ?? '')),
            'service' => (int) ($in['service_id'] ?? 0),
            'date' => trim((string) ($in['date'] ?? '')),
            'time' => trim((string) ($in['time'] ?? '')),
            'notes' => trim((string) ($in['notes'] ?? '')),
        ];
        $e = [];
        if (mb_strlen($v['name']) < 2) $e['name'] = 'Informe seu nome.';
        elseif (mb_strlen($v['name']) > 100) $e['name'] = 'Nome muito longo.';
        if (strlen($v['phone']) < 10 || strlen($v['phone']) > 11) $e['phone'] = 'Informe o WhatsApp com DDD (ex.: 11 91234-5678).';
        if (mb_strlen($v['notes']) > 255) $e['notes'] = 'Observação muito longa (máx. 255 caracteres).';
        $svc = $v['service'] ? $this->services->find($v['service']) : null;
        if (!$svc || (!$fromPanel && !(int) $svc['active'])) $e['service'] = 'Escolha um serviço.';
        if (!valid_date($v['date'])) $e['date'] = 'Escolha o dia.';
        if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $v['time'])) $e['time'] = 'Escolha o horário.';
        if ($e) {
            return ['ok' => false, 'status' => 422, 'errors' => $e, 'message' => 'Confira os campos destacados.'];
        }
        if (!$fromPanel && $this->bookings->countFutureByPhone($v['phone']) >= self::MAX_FUTURE_PER_PHONE) {
            return ['ok' => false, 'status' => 422, 'errors' => ['phone' => 'Você já tem ' . self::MAX_FUTURE_PER_PHONE . ' horários marcados. Para marcar mais, chame no WhatsApp.'], 'message' => 'Limite de agendamentos atingido.'];
        }

        $duration = (int) $svc['duration_min'];
        $start = to_min($v['time']);
        $end = $start + $duration;
        if ($end > 24 * 60) {
            return ['ok' => false, 'status' => 422, 'errors' => ['time' => 'O serviço passaria da meia-noite.'], 'message' => 'Horário inválido.'];
        }

        // Trava global curta: dois pedidos ao mesmo tempo não pegam o mesmo horário
        $pdo = DB::connection();
        $got = (int) ($pdo->query("SELECT GET_LOCK('manicure_booking', 10)")->fetchColumn() ?: 0);
        if ($got !== 1) {
            return ['ok' => false, 'status' => 503, 'message' => 'Agenda ocupada no momento. Tente de novo em alguns segundos.'];
        }
        try {
            $avail = new AvailabilityService();
            $free = $force
                ? $avail->noBookingConflict($v['date'], $start, $end)
                : $avail->isFree($v['date'], $v['time'], $duration, !$fromPanel);
            if (!$free) {
                return ['ok' => false, 'status' => 409, 'code' => 'taken', 'errors' => ['time' => 'Este horário acabou de ser ocupado. Escolha outro.'], 'message' => 'Horário indisponível.'];
            }
            $code = $this->newCode();
            $id = $this->bookings->create([
                'code' => $code,
                'service_id' => (int) $svc['service_id'],
                'service_name' => $svc['name'],
                'price' => $svc['price'],
                'duration_min' => $duration,
                'client_name' => $v['name'],
                'client_phone' => $v['phone'],
                'notes' => $v['notes'] !== '' ? $v['notes'] : null,
                'booking_date' => $v['date'],
                'start_time' => to_hhmm($start) . ':00',
                'end_time' => to_hhmm($end) . ':00',
                'status' => 'confirmado',
                'source' => $fromPanel ? 'painel' : 'site',
            ]);
        } finally {
            $pdo->query("SELECT RELEASE_LOCK('manicure_booking')");
        }
        return ['ok' => true, 'status' => 201, 'booking' => self::present($this->bookings->find($id))];
    }

    public function setStatus(int $id, string $status): array
    {
        if (!in_array($status, self::STATUSES, true)) {
            return ['ok' => false, 'status' => 422, 'message' => 'Situação inválida.'];
        }
        $b = $this->bookings->find($id);
        if (!$b) return ['ok' => false, 'status' => 404, 'message' => 'Agendamento não encontrado.'];
        if ($status === 'confirmado' && $b['status'] === 'cancelado') {
            // reativar só se o horário continuar livre
            if (!(new AvailabilityService())->noBookingConflict($b['booking_date'], to_min($b['start_time']), to_min($b['end_time']))) {
                return ['ok' => false, 'status' => 409, 'message' => 'Esse horário já foi ocupado por outra cliente.'];
            }
        }
        $this->bookings->update($id, ['status' => $status]);
        return ['ok' => true, 'status' => 200, 'booking' => self::present($this->bookings->find($id))];
    }

    public static function present(array $b): array
    {
        return [
            'id' => (int) $b['booking_id'],
            'code' => $b['code'],
            'service_id' => $b['service_id'] !== null ? (int) $b['service_id'] : null,
            'service' => $b['service_name'],
            'price' => (float) $b['price'],
            'duration' => (int) $b['duration_min'],
            'name' => $b['client_name'],
            'phone' => $b['client_phone'],
            'phone_fmt' => format_phone($b['client_phone']),
            'notes' => $b['notes'],
            'date' => $b['booking_date'],
            'start' => substr($b['start_time'], 0, 5),
            'end' => substr($b['end_time'], 0, 5),
            'status' => $b['status'],
            'source' => $b['source'],
            'created_at' => $b['created_at'],
        ];
    }

    private function newCode(): string
    {
        $abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        do {
            $c = '';
            for ($i = 0; $i < 6; $i++) $c .= $abc[random_int(0, strlen($abc) - 1)];
        } while ($this->bookings->codeExists($c));
        return $c;
    }
}
