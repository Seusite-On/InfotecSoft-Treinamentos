<?php

use App\Core\Route;
use App\Controllers\AppController;
use App\Controllers\AuthController;
use App\Controllers\StateController;
use App\Controllers\AvailabilityController;
use App\Controllers\BookingController;
use App\Controllers\AdminController;

// Página única (agenda pública + painel da manicure em #painel)
Route::get('/', [AppController::class, 'index']);

// Estado inicial: dados do salão, serviços, horário de funcionamento e (se logada) a usuária
Route::get('/api/state', [StateController::class, 'show']);

// Calendário público: dias com vaga no mês e horários livres de um dia
Route::get('/api/calendar', [AvailabilityController::class, 'calendar']);
Route::get('/api/slots', [AvailabilityController::class, 'slots']);

// Cliente agenda um horário
Route::post('/api/bookings', [BookingController::class, 'store']);

// Autenticação do painel
Route::post('/api/login', [AuthController::class, 'login']);
Route::post('/api/logout', [AuthController::class, 'logout']);
Route::post('/api/password', [AuthController::class, 'changePassword']);

// Painel: agenda
Route::get('/api/admin/bookings', [BookingController::class, 'index']);
Route::post('/api/admin/bookings', [BookingController::class, 'adminStore']);
Route::post('/api/admin/bookings/{id}/status', [BookingController::class, 'status']);

// Painel: serviços
Route::post('/api/admin/services', [AdminController::class, 'saveService']);
Route::post('/api/admin/services/{id}/delete', [AdminController::class, 'deleteService']);

// Painel: horário de funcionamento, bloqueios (folgas/feriados) e configurações
Route::post('/api/admin/hours', [AdminController::class, 'saveHours']);
Route::get('/api/admin/blocks', [AdminController::class, 'blocks']);
Route::post('/api/admin/blocks', [AdminController::class, 'addBlock']);
Route::post('/api/admin/blocks/{id}/delete', [AdminController::class, 'deleteBlock']);
Route::post('/api/admin/settings', [AdminController::class, 'saveSettings']);
